import { Component } from '@angular/core';

@Component({
    selector: 'main-footer',
    templateUrl: './app/footer/footer.component.html',
    styleUrls:['./app/footer/footer.component.css']
})
export class FooterComponent{
    constructor() { }

   
}