import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<view-contacts></view-contacts>
            `,
})
export class AppComponent  { name = 'Angular'; }
