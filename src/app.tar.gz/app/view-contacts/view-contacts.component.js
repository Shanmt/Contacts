"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var contacts = [
    { "id": 1, "name": "abc1", "phone": "99999999991", "email": "abc1@abc.com" },
    { "id": 2, "name": "abc2", "phone": "99999999992", "email": "abc2@abc.com" },
    { "id": 3, "name": "abc3", "phone": "99999999993", "email": "abc3@abc.com" },
    { "id": 4, "name": "abc4", "phone": "99999999994", "email": "abc4@abc.com" },
    { "id": 5, "name": "abc5", "phone": "99999999995", "email": "abc5@abc.com" },
    { "id": 6, "name": "abc6", "phone": "99999999996", "email": "abc6@abc.com" },
    { "id": 7, "name": "abc7", "phone": "99999999997", "email": "abc7@abc.com" }
];
var ViewContactsComponent = (function () {
    function ViewContactsComponent() {
        this.allcontacts = contacts;
    }
    ViewContactsComponent = __decorate([
        core_1.Component({
            selector: 'view-contacts',
            templateUrl: './app/view-contacts/view-contacts.component.html',
            styleUrls: ['./app/view-contacts/view-contacts.component.css']
        }), 
        __metadata('design:paramtypes', [])
    ], ViewContactsComponent);
    return ViewContactsComponent;
}());
exports.ViewContactsComponent = ViewContactsComponent;
//# sourceMappingURL=view-contacts.component.js.map